Pixel Worlds - 379 Haunted West Props (Free)
============================================

379 isometric pixel-art props (2:1 view, light from the top left), free to use.
Each prop is a separate transparent PNG in three sizes: _1x (native), _2x and _4x
(exact nearest-neighbour upscales, no blur). Folders group the props by room or theme.
previews/ shows every prop at 2x.

Made with: Krea 2 Turbo by Krea AI (AI-generated), then cut and pixel-cleaned by SdavGha.

Tile grid (version 3)
---------------------
Isometric diamond tile: 64x32 px at 1x, 128x64 at 2x, 256x128 at 4x.
Pivot: the bottom-centre of every image. Put the pivot on the BOTTOM corner of the tile
(the corner nearest the viewer) and the prop stands on that tile.
Images can be wider and taller than the tile - tops of props overhang, like real furniture.

Footprint codes in the list below:
  1x1                       stands on one tile (its base is 64 px wide at 1x)
  1x1 (smaller than ...)    small item, kept at its natural size and centred on the tile
  1x1 (overhangs ...)       long item (broom, telescope, rug): the part that touches the floor sits
                            on the tile, the rest reaches over the tiles next to it
  2x1                       base 96 px wide at 1x = two tiles side by side; the long side
                            follows the drawing. The pivot is the lowest corner of the two-tile footprint.
  2x1 (smaller than ...)    item narrower than a two-tile base but too wide to shrink onto one tile,
                            kept at its natural size and centred on the 2x1 footprint
  1x1 centre-line           thin standing slab: gravestone, stone tablet (2 props). The image
                            has 16 px of empty space under it (32 at 2x, 64 at 4x), so with the usual
                            pivot its base line runs through the middle of the tile.
  wall-left N / wall-right N   wall decoration (13 props): pictures, windows, shields, clocks
                            and a cell door.
                            Drawn flat on a wall at the 2:1 angle. With the usual pivot on a floor tile
                            it sits on that tile's back wall - left wall = the tile's top-left edge,
                            right wall = the tile's top-right edge. N = wall tiles it covers: the
                            pivot tile is the front one, the prop runs N tiles towards the room's
                            back corner. Its lower edge touches the foot of the wall; move it up
                            to hang it higher. Flip it horizontally to use it on the other wall
                            (the light direction flips too).

Scale note: props are not all drawn to one real-world scale - some large pieces are
smaller than life next to small items. Resize to taste.

Contents (size at 1x, footprint)


  Dracula_Castle/Armory
    suit_black_armor_stand                      64x87     1x1 (smaller than the tile, centred)
    rack_rapiers                                84x87     1x1
    halberd_stand                               64x102    1x1 (smaller than the tile, centred)
    black_shield_bat_crest                      52x114    wall-right 2
    crossbow_table                              88x74     1x1
    quiver_silver_arrows                        64x82     1x1 (smaller than the tile, centred)
    stack_helmets                               64x82     1x1 (smaller than the tile, centred)
    mace_rack                                   94x87     1x1 (overhangs nearby tiles)
    weapon_chest                                66x68     1x1
    wooden_training_dummy                       64x89     1x1 (smaller than the tile, centred)
    grindstone                                  68x78     1x1 (smaller than the tile, centred)
    rack_stakes                                 82x81     1x1
    silver_sword_pedestal                       64x95     1x1 (smaller than the tile, centred)
    pile_chainmail                              66x52     1x1
    cannon_skull_decoration                     96x84     2x1 (smaller than the footprint, centred)
    barrel_torches                              64x88     1x1 (smaller than the tile, centred)

  Dracula_Castle/Ballroom
    ballroom_chair_gold_trim                    64x89     1x1 (smaller than the tile, centred)
    tall_floor_candelabra                       64x97     1x1 (smaller than the tile, centred)
    punch_bowl_red_punch                        64x73     1x1 (smaller than the tile, centred)
    mask_stand                                  64x80     1x1 (smaller than the tile, centred)
    feather_fan                                 80x64     1x1 (smaller than the tile, centred)
    champagne_tower                             64x86     1x1 (smaller than the tile, centred)
    velvet_chaise                               74x71     1x1
    potted_dead_rose_bush                       64x83     1x1 (smaller than the tile, centred)
    gold_mirror_stand                           64x87     1x1 (smaller than the tile, centred)
    small_round_table_masks                     66x75     1x1
    cloak_mannequin                             64x86     1x1
    dance_card_tray                             64x53     1x1
    gown_mannequin                              64x84     1x1
    crystal_decanter_set                        66x89     1x1
    gold_ice_bucket                             64x63     1x1 (smaller than the tile, centred)
    bouquet_black_roses                         64x77     1x1 (smaller than the tile, centred)

  Dracula_Castle/Banquet
    gothic_high_backed_dining_chair             64x99     1x1 (smaller than the tile, centred)
    silver_platter_roast                        70x47     1x1
    crystal_goblet_red_wine                     64x65     1x1 (smaller than the tile, centred)
    tall_silver_candlestick                     64x89     1x1 (smaller than the tile, centred)
    bowl_dark_red_grapes                        66x65     1x1
    wine_decanter_red_wine                      64x74     1x1 (smaller than the tile, centred)
    silver_cloche_dome                          66x58     1x1
    stack_fine_plates                           64x53     1x1
    three_tier_cake_red_icing                   66x70     1x1
    pewter_pitcher                              64x66     1x1 (smaller than the tile, centred)
    bowl_blood_red_soup                         66x48     1x1
    cheese_board_knife                          68x49     1x1
    silver_cutlery_set_napkin                   68x41     1x1
    toppled_wine_glass                          74x48     1x1
    basket_black_bread                          66x59     1x1
    carved_roast_turkey                         70x57     1x1

  Dracula_Castle/Bedroom
    black_velvet_armchair                       64x86     1x1 (smaller than the tile, centred)
    nightstand_candle                           64x91     1x1 (smaller than the tile, centred)
    jewelry_box_rubies                          74x72     1x1
    gothic_vanity_broken_mirror                 68x103    1x1
    silk_folding_screen_bats                    66x79     1x1
    chest_at_foot_bed                           96x81     2x1 (smaller than the footprint, centred)
    red_velvet_pillow                           66x43     1x1
    lace_nightgown_hanger                       64x86     1x1 (smaller than the tile, centred)
    perfume_bottle_set                          66x76     1x1 (smaller than the tile, centred)
    silver_hand_mirror                          64x65     1x1 (smaller than the tile, centred)
    music_box_dancer                            68x67     1x1 (smaller than the tile, centred)
    rose_crystal_vase                           64x75     1x1 (smaller than the tile, centred)
    pair_red_heeled_shoes                       64x52     1x1 (smaller than the tile, centred)
    black_lace_fan                              72x65     1x1 (smaller than the tile, centred)
    tall_wardrobe_mirror                        64x97     1x1 (smaller than the tile, centred)
    rug_made_black_fur                          96x52     2x1 (smaller than the footprint, centred)

  Dracula_Castle/Cellar
    rack_dusty_wine_bottles                     68x74     1x1
    large_wine_cask_side                        96x84     2x1 (smaller than the footprint, centred)
    crate_blood_red_wine                        66x76     1x1
    wine_tasting_table                          78x76     1x1
    corkscrew_corks                             66x49     1x1
    dusty_wine_bottle_cobwebs                   68x88     1x1
    cellar_lantern                              64x84     1x1 (smaller than the tile, centred)
    barrel_tap_drip                             70x73     1x1
    stack_small_barrels                         66x72     1x1
    broken_wine_bottle                          70x49     1x1
    cellar_ladder                               68x87     1x1 (smaller than the tile, centred)
    sack_grain                                  68x66     1x1
    cheese_wheel_shelf                          66x80     1x1
    hanging_cured_ham                           64x83     1x1 (smaller than the tile, centred)
    jar_pickles                                 64x73     1x1 (smaller than the tile, centred)
    padlocked_cellar_chest                      66x66     1x1

  Dracula_Castle/Chapel
    cracked_stone_font                          64x89     1x1 centre-line
    broken_pew                                  66x74     1x1
    candle_rack_many_candles                    76x86     1x1
    stone_altar_cloth_dagger                    66x69     1x1
    broken_church_bell                          64x76     1x1 (smaller than the tile, centred)
    incense_burner_chain                        64x78     1x1 (smaller than the tile, centred)
    cracked_stained_glass_panel_stand           64x81     1x1
    stone_gargoyle                              68x84     1x1 (smaller than the tile, centred)
    rosary_stand                                64x76     1x1 (smaller than the tile, centred)
    wooden_prayer_stand                         64x75     1x1 (smaller than the tile, centred)
    broken_angel_statue                         64x79     1x1 (smaller than the tile, centred)
    skull_candle_holder                         64x80     1x1 (smaller than the tile, centred)
    dark_ritual_book_altar                      66x74     1x1
    chalice_dark_liquid                         64x61     1x1 (smaller than the tile, centred)
    broken_stone_cross                          64x79     1x1 (smaller than the tile, centred)
    ring_black_candles                          66x64     1x1

  Dracula_Castle/Crypt
    bat_hanging_upside_down                     64x86     1x1 (smaller than the tile, centred)
    cluster_sleeping_bats                       66x56     1x1
    bat_roost_wooden_beam                       70x76     1x1
    vampire_coffin_lid                          66x63     1x1
    pile_grave_soil                             68x45     1x1
    garlic_wreath                               66x52     1x1
    wooden_stake_hammer                         90x54     1x1 (overhangs nearby tiles)
    silver_cross_floor                          66x43     1x1
    bowl_blood                                  64x52     1x1
    broken_mirror_shards                        74x49     1x1
    cloak_lying_floor                           68x53     1x1
    candle_stub_wax                             64x57     1x1 (smaller than the tile, centred)
    red_rose_coffin                             66x66     1x1
    vampire_fangs_box                           66x57     1x1
    lantern_red_flame                           64x87     1x1 (smaller than the tile, centred)
    burial_urn_bat                              76x92     1x1 (smaller than the tile, centred)

  Dracula_Castle/Dungeon
    pair_iron_shackles                          66x45     1x1
    rusty_iron_chair                            64x80     1x1 (smaller than the tile, centred)
    wooden_stretching_rack                      82x82     1x1
    spiked_iron_collar                          68x45     1x1
    cage_hanging_from_stand                     64x80     1x1 (smaller than the tile, centred)
    bucket_murky_water                          64x56     1x1 (smaller than the tile, centred)
    iron_brand_hot_coals                        66x77     1x1
    wooden_stocks                               78x84     1x1
    pile_chains                                 66x43     1x1
    rusty_saw_table                             76x59     1x1
    skeleton_chained_post                       64x86     1x1 (smaller than the tile, centred)
    bloody_wooden_table                         74x55     1x1
    jailer_key_ring_hook                        64x73     1x1 (smaller than the tile, centred)
    straw_prison_bed                            96x82     2x1 (smaller than the footprint, centred)
    rat_crate                                   66x73     1x1
    iron_maiden                                 64x88     1x1

  Dracula_Castle/Entrance
    gothic_iron_candelabra                      64x93     1x1 (smaller than the tile, centred)
    red_velvet_bench                            72x67     1x1
    coat_rack_black_cape                        64x90     1x1 (smaller than the tile, centred)
    stone_bowl_holy_water_dried                 64x59     1x1 (smaller than the tile, centred)
    iron_umbrella_stand_cane                    64x80     1x1 (smaller than the tile, centred)
    gothic_side_table_skull                     64x80     1x1 (smaller than the tile, centred)
    bronze_bat_statuette                        64x76     1x1 (smaller than the tile, centred)
    dusty_welcome_mat_bat_crest                 98x52     2x1 (smaller than the footprint, centred)
    wall_shield_crossed_swords_stand            64x88     1x1
    ornate_black_vase_dead_roses                64x84     1x1 (smaller than the tile, centred)
    red_carpet_runner_end_piece                 96x59     2x1 (smaller than the footprint, centred)
    hanging_iron_lantern_stand                  70x85     1x1 (smaller than the tile, centred)
    guest_book_lectern                          64x89     1x1 (smaller than the tile, centred)
    stone_gargoyle_bookend                      82x72     1x1
    black_cat_cushion                           96x71     2x1 (smaller than the footprint, centred)
    tall_gothic_mirror                          68x102    1x1 (smaller than the tile, centred)

  Dracula_Castle/Gallery
    framed_portrait_pale_nobleman               54x115    wall-left 2
    framed_portrait_noble_lady                  56x115    wall-left 2
    portrait_glowing_red_eyes                   54x114    wall-left 2
    covered_painting_sheet                      70x88     1x1
    small_oval_portrait_stand                   64x83     1x1 (smaller than the tile, centred)
    landscape_painting_castle                   70x105    wall-left 2
    broken_empty_picture_frame                  58x106    wall-left 2
    velvet_rope_barrier_post                    70x77     1x1 (smaller than the tile, centred)
    marble_bust_vampire_count                   64x83     1x1 (smaller than the tile, centred)
    bronze_knight_bust                          64x90     1x1 (smaller than the tile, centred)
    display_case_dagger                         64x94     1x1
    gilded_easel                                64x98     1x1 (smaller than the tile, centred)
    stack_framed_paintings                      66x79     1x1
    ripped_portrait                             60x112    wall-left 2
    portrait_black_wolf                         60x111    wall-left 2
    family_crest_plaque_stand                   64x88     1x1

  Dracula_Castle/Garden
    dead_rose_bush                              68x74     1x1
    cracked_stone_bench                         76x57     1x1
    cracked_stone_birdbath                      70x80     1x1 (smaller than the tile, centred)
    black_iron_garden_bench                     96x95     2x1 (smaller than the footprint, centred)
    withered_tree_stump_crow                    66x72     1x1
    stone_urn_planter_dead_flowers              64x87     1x1 (smaller than the tile, centred)
    broken_fountain_spout                       64x68     1x1 (smaller than the tile, centred)
    garden_lantern_red_light                    64x81     1x1 (smaller than the tile, centred)
    pile_dead_leaves                            66x38     1x1
    pumpkin_face                                64x60     1x1
    gravestone_skull                            76x97     1x1 centre-line
    statue_weeping_maiden                       64x97     1x1 (smaller than the tile, centred)
    stone_gargoyle_pillar                       64x102    1x1 (smaller than the tile, centred)
    wrought_iron_gate_piece                     64x94     1x1 (smaller than the tile, centred)
    thorn_bramble                               72x57     1x1
    vase_black_roses                            64x81     1x1 (smaller than the tile, centred)

  Dracula_Castle/Kitchen
    cauldron_red_stew                           70x73     1x1
    butcher_block_cleavers                      68x90     1x1
    rack_hanging_garlic                         68x90     1x1
    shelf_red_wine_bottles                      68x93     1x1
    basket_red_apples                           66x68     1x1
    pantry_shelf_jars                           64x86     1x1
    cutting_board_meat                          66x51     1x1
    spice_rack                                  72x86     1x1
    kitchen_stove_fire                          72x76     1x1
    barrel_red_wine                             64x78     1x1
    rolling_pin_dough                           66x64     1x1
    basket_mushrooms                            66x70     1x1
    hanging_ladle_set                           64x79     1x1 (smaller than the tile, centred)
    bowl_eggs                                   66x48     1x1
    sack_potatoes                               66x63     1x1
    jug_milk                                    68x74     1x1 (smaller than the tile, centred)

  Dracula_Castle/Lab
    lightning_rod_coil_machine                  66x83     1x1 (smaller than the tile, centred)
    jar_floating_brain                          64x67     1x1 (smaller than the tile, centred)
    bubbling_flask_red_liquid                   64x74     1x1 (smaller than the tile, centred)
    skeleton_anatomy_model                      64x79     1x1 (smaller than the tile, centred)
    surgical_tray_tools                         66x67     1x1 (smaller than the tile, centred)
    blood_vial_rack                             64x70     1x1
    bat_glass_jar                               64x74     1x1 (smaller than the tile, centred)
    strange_glowing_crystal                     64x63     1x1 (smaller than the tile, centred)
    bellows_furnace_for_alchemy                 64x75     1x1
    cage_bat                                    64x70     1x1 (smaller than the tile, centred)
    book_dark_experiments                       66x51     1x1
    mortar_garlic                               64x59     1x1 (smaller than the tile, centred)
    microscope                                  64x81     1x1 (smaller than the tile, centred)
    coffin_shaped_cabinet                       64x80     1x1 (smaller than the tile, centred)
    tray_glowing_potions                        66x65     1x1
    skull_wires                                 64x69     1x1 (smaller than the tile, centred)

  Dracula_Castle/Large_Castle
    castle_gate_tower                           110x137   2x1
    stone_gargoyle_tall_pillar                  74x139    1x1 (smaller than the tile, centred)
    gothic_arch_doorway                         74x109    1x1
    castle_wall_corner_tower                    102x117   2x1
    drawbridge_chains                           98x114    2x1
    castle_well_bat_statue                      66x110    1x1

  Dracula_Castle/Large_Dungeon
    iron_prison_cell                            100x114   2x1
    torture_wheel                               86x96     1x1
    gallows_platform                            98x124    2x1
    large_iron_cage                             96x126    2x1
    dungeon_gate                                98x128    2x1 (smaller than the footprint, centred)
    guillotine                                  78x107    1x1

  Dracula_Castle/Large_Hall
    grand_vampire_throne_bat_wings              108x123   2x1 (smaller than the footprint, centred)
    long_banquet_table_candles                  104x78    2x1
    grand_staircase_red_carpet                  102x118   2x1
    huge_stone_fireplace_crest                  96x134    2x1 (smaller than the footprint, centred)
    giant_crystal_chandelier                    96x123    2x1
    tall_grandfather_clock_bat                  64x138    1x1 (smaller than the tile, centred)

  Dracula_Castle/Large_Misc
    vampire_statue_pedestal                     64x122    1x1 (smaller than the tile, centred)
    large_stone_sarcophagus_carved_lid          104x98    2x1
    giant_bat_statue                            102x109   1x1 (overhangs nearby tiles)
    blood_fountain                              96x123    2x1 (smaller than the footprint, centred)
    harp_stage                                  96x114    2x1
    tall_candelabra_tree                        70x127    1x1 (smaller than the tile, centred)

  Dracula_Castle/Large_Rooms
    gothic_four_poster_bed_red                  102x131   2x1
    black_lacquered_coffin_pedestal             108x106   2x1
    grand_pipe_organ                            96x137    2x1 (smaller than the footprint, centred)
    tall_bookshelf_wall_section                 102x138   2x1
    gothic_wardrobe                             96x143    2x1 (smaller than the footprint, centred)
    large_stained_glass_window_panel            106x163   wall-left 3

  Dracula_Castle/Library
    pile_old_leather_books                      96x77     2x1 (smaller than the footprint, centred)
    open_spellbook_stand                        78x85     1x1 (smaller than the tile, centred)
    rolling_library_ladder                      66x87     1x1
    reading_chair_red_cushion                   64x94     1x1
    desk_candles_scrolls                        78x84     1x1
    globe_night_sky                             64x86     1x1 (smaller than the tile, centred)
    skull_candle                                64x86     1x1 (smaller than the tile, centred)
    quill_inkwell                               88x81     1x1 (smaller than the tile, centred)
    stack_scrolls_basket                        70x72     1x1
    chained_forbidden_book                      96x64     2x1 (smaller than the footprint, centred)
    book_bat_clasp                              66x48     1x1
    magnifying_glass_map                        96x54     2x1 (smaller than the footprint, centred)
    hourglass_red_sand                          64x84     1x1 (smaller than the tile, centred)
    reading_lamp_red_shade                      64x81     1x1 (smaller than the tile, centred)
    small_book_cart                             80x78     1x1
    dusty_encyclopedia_stack                    66x75     1x1

  Dracula_Castle/Music
    gothic_harpsichord_stool                    70x88     1x1
    violin_stand                                64x84     1x1 (smaller than the tile, centred)
    cello_leaning_chair                         64x97     1x1 (smaller than the tile, centred)
    music_stand_sheets                          64x79     1x1 (smaller than the tile, centred)
    gramophone_black_horn                       66x90     1x1 (smaller than the tile, centred)
    harp_broken_strings                         64x87     1x1 (smaller than the tile, centred)
    drum_skull_painting                         64x67     1x1
    flute_cushion                               66x63     1x1
    candelabra_piano_lid                        70x89     1x1
    stack_music_books                           64x65     1x1 (smaller than the tile, centred)
    lute_red_ribbons                            70x81     1x1
    metronome                                   64x68     1x1 (smaller than the tile, centred)
    bell_tree                                   68x87     1x1 (smaller than the tile, centred)
    pipe_organ_bench                            64x91     1x1
    accordion                                   72x56     1x1
    tambourine                                  64x54     1x1 (smaller than the tile, centred)

  Dracula_Castle/Servants
    servant_bell_board                          64x88     1x1 (smaller than the tile, centred)
    laundry_basket_linens                       64x62     1x1
    mop_bucket                                  78x86     1x1
    sewing_basket                               64x67     1x1
    candle_making_table                         72x86     1x1
    shoe_polishing_kit                          70x79     1x1
    ironing_board_iron                          78x72     1x1
    tray_tea_cups                               96x54     2x1 (smaller than the footprint, centred)
    stack_folded_towels                         64x55     1x1
    servant_uniform_hanger                      64x80     1x1 (smaller than the tile, centred)
    lantern_key_hook                            64x80     1x1 (smaller than the tile, centred)
    feather_duster                              74x67     1x1 (smaller than the tile, centred)
    bucket_coal                                 64x51     1x1 (smaller than the tile, centred)
    tin_bath_tub                                70x59     1x1
    wooden_servant_bed                          96x83     2x1 (smaller than the footprint, centred)
    cupboard_candles                            64x95     1x1 (smaller than the tile, centred)

  Dracula_Castle/Throne
    royal_red_cushion_crown                     96x67     2x1
    scepter_pillow                              96x66     2x1 (smaller than the footprint, centred)
    pair_iron_braziers_red_fire                 68x79     1x1
    royal_banner_bat_emblem                     64x87     1x1 (smaller than the tile, centred)
    goblet_pedestal                             64x89     1x1 (smaller than the tile, centred)
    kneeling_cushion                            96x51     2x1 (smaller than the footprint, centred)
    wolf_statue                                 64x90     1x1
    stand_ceremonial_sword                      64x91     1x1 (smaller than the tile, centred)
    chest_royal_jewels                          74x66     1x1
    bat_shaped_candelabra                       78x88     1x1 (smaller than the tile, centred)
    red_carpet_gold_trim_piece                  104x61    1x1 (overhangs nearby tiles)
    gong_bat_symbol                             84x87     1x1
    raven_perch                                 64x87     1x1 (smaller than the tile, centred)
    crown_stand                                 64x87     1x1 (smaller than the tile, centred)
    velvet_rope_gold_posts                      78x87     1x1
    stone_pedestal_glowing_ruby                 64x87     1x1 (smaller than the tile, centred)

  Dracula_Castle/Tower
    large_clock_gear                            104x126   wall-left 3
    clock_pendulum                              64x92     1x1 (smaller than the tile, centred)
    bell_rope                                   74x89     1x1 (smaller than the tile, centred)
    broken_clock_face                           70x117    wall-left 2
    crate_gears                                 66x71     1x1
    old_telescope                               108x82    1x1 (overhangs nearby tiles)
    wind_vane_bat                               96x89     2x1 (smaller than the footprint, centred)
    raven_nest                                  72x56     1x1
    pile_broken_roof_tiles                      96x76     2x1
    lever_chains                                78x83     1x1
    lantern_hook                                64x87     1x1 (smaller than the tile, centred)
    broken_window_frame                         54x112    wall-left 2
    rope_coil                                   66x59     1x1
    bucket_oil                                  68x64     1x1
    crow_skull                                  82x66     1x1
    small_bell                                  64x65     1x1 (smaller than the tile, centred)

  Ground_Decals/Graveyard
    flat_fresh_grave_dirt_mound                 66x42     1x1
    flat_sunken_grave_plot                      72x42     1x1
    flat_scatter_withered_flowers               68x43     1x1
    flat_ring_lit_candles                       66x56     1x1
    flat_open_grave_hole                        70x45     1x1
    flat_broken_tombstone_piece                 64x51     1x1
    flat_scatter_dead_brown_leaves              70x44     1x1
    flat_iron_grave_marker_plate                66x42     1x1
    flat_pile_bones_dirt                        66x42     1x1
    flat_wreath_dried_flowers                   66x46     1x1
    flat_cracked_stone_path_tile                96x53     2x1 (smaller than the footprint, centred)
    flat_dug_up_dirt_pile                       66x69     1x1
    flat_scatter_black_feathers                 66x42     1x1
    flat_cobweb_covered_stone                   72x51     1x1
    flat_lantern_lying_side                     70x53     1x1 (smaller than the tile, centred)

  Ground_Decals/Halloween
    flat_scatter_wrapped_candies                68x45     1x1
    flat_pile_autumn_leaves_small               96x54     2x1 (smaller than the footprint, centred)
    flat_scatter_candy_corn                     66x42     1x1
    flat_spilled_cauldron_orange_potion         66x53     1x1
    flat_witch_hat_lying_ground                 66x47     1x1
    flat_broom_lying_ground                     108x55    1x1 (overhangs nearby tiles)
    flat_scatter_black_cat_paw                  70x50     1x1
    flat_ring_glowing_orange_candles            66x52     1x1
    flat_skull_candle_top                       64x71     1x1 (smaller than the tile, centred)
    flat_spiderweb_ground                       66x41     1x1
    flat_scatter_bats_paper_cutouts             66x41     1x1
    flat_treat_bag_spilling_candy               66x49     1x1
    flat_glowing_purple_potion_puddle           66x35     1x1
    flat_pile_dry_bones_leaves                  70x44     1x1

  Haunted_Wild_West/Haunted
    haunted_portrait_easel                      64x89     1x1 (smaller than the tile, centred)
    creepy_doll_chair                           64x78     1x1 (smaller than the tile, centred)
    cracked_standing_mirror                     64x91     1x1 (smaller than the tile, centred)
    old_dusty_organ                             70x86     1x1
    spider_egg_sac                              64x61     1x1
    cauldron_bones                              64x71     1x1
    raven_cage                                  64x85     1x1 (smaller than the tile, centred)
    coffin_wrapped_chains                       64x87     1x1 (smaller than the tile, centred)
    cursed_chest_eyes                           66x67     1x1
    creepy_jack_box                             74x84     1x1 (smaller than the tile, centred)
    broken_grandfather_clock                    64x89     1x1 (smaller than the tile, centred)
    candelabra_dripping_wax                     64x83     1x1 (smaller than the tile, centred)
    old_rocking_horse                           90x69     1x1 (overhangs nearby tiles)
    stone_gargoyle_fountain                     64x90     1x1
    witch_broom_stand                           64x89     1x1 (smaller than the tile, centred)
    skeleton_sitting_chair                      64x90     1x1 (smaller than the tile, centred)

  Haunted_Wild_West/Wild_West
    pair_saloon_swinging_doors                  64x85     1x1 (smaller than the tile, centred)
    blank_wanted_poster_board                   64x85     1x1 (smaller than the tile, centred)
    wooden_water_tower                          64x86     1x1 (smaller than the tile, centred)
    stagecoach                                  96x89     2x1 (smaller than the footprint, centred)
    wooden_hitching_rail                        68x73     1x1 (smaller than the tile, centred)
    barrel_whiskey                              64x53     1x1 (smaller than the tile, centred)
    cattle_skull_post                           64x71     1x1 (smaller than the tile, centred)
    gold_mining_sluice_box                      88x63     1x1
    windmill_water_pump                         66x82     1x1 (smaller than the tile, centred)
    iron_jail_cell_door                         42x102    wall-right 2
    coffin_standing_upright                     64x78     1x1 (smaller than the tile, centred)
    spooky_scarecrow                            68x84     1x1 (smaller than the tile, centred)
    crow_fence_post                             64x76     1x1 (smaller than the tile, centred)
    lantern_purple_flame                        64x60     1x1 (smaller than the tile, centred)
    stack_wagon_wheels                          66x54     1x1
    wooden_porch_rocking_chair                  64x79     1x1
